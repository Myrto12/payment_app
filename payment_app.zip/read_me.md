## Michalopoulou Myrto

## Run app
    To execute the program, run the following command in your terminal:
    python3 pay_v2.py

## How to use
    Organise your monthly payments. Choose the month you want and add your payments, click on the checkbox to set them as 'completed', press the 'bin' button to delete them. Press back to go back to main menu and choose another month.