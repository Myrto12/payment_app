from flask import Flask, render_template,request,redirect,url_for
import json
from datetime import datetime
pay = Flask(__name__)

def getTasks():
    try:
        with open('Tasks.json', encoding="utf8") as json_file:
            return json.load(json_file)
    except (json.JSONDecodeError, FileNotFoundError):
        return []  

def addtask(task):
    Tasks = getTasks()
    Tasks.append(task)
    with open('Tasks.json','w',encoding="utf8") as json_file:
        return json.dump(Tasks,json_file,ensure_ascii=False)

def change_state(id):
    Tasks = getTasks()
    task = next(filter(lambda x: x['id'] == int(id), Tasks))
    task['state'] = abs(task['state'] - 1) 
    with open('Tasks.json','w',encoding="utf8") as json_file:
        return json.dump(Tasks,json_file,ensure_ascii=False)
        
def delete_task(id):
    Tasks = getTasks()
    Tasks = [task for task in Tasks if task['id'] != int(id)] 
    with open('Tasks.json','w',encoding="utf8") as json_file:
        return json.dump(Tasks, json_file, ensure_ascii=False)


@pay.route('/',methods=['GET','POST'])
def choose_month():
    if request.method == 'POST':
        selected_month = request.form.get('selected_month','Ιανουάριος')
        global current_month
        current_month = selected_month
        return redirect(url_for('index'))
    return render_template('main.html')
    
current_month = 'Ιανουάριος'

@pay.route('/payments',methods=['GET','POST'])
def index():
    global current_month
    if request.method=='POST':
        task_name = request.form.get('task_name','all')
        taskdict = {
            'id' : int(datetime.timestamp(datetime.now())),
            'name' : task_name,
            'state' : 0,
            'created at' : datetime.now().strftime("%d/%m/%Y, %H:%M:%S"),
            'deadline' : current_month
        }
        addtask(taskdict)
    all_tasks = getTasks()
    filtered_tasks = list(filter(lambda t: t.get('deadline')==current_month,all_tasks))
    return render_template('index.html',Tasks=filtered_tasks,selected_month=current_month)

@pay.route('/change_state/<id>')
def change_state_route(id):
    change_state(id)
    return redirect(url_for('index'))

@pay.route('/delete/<id>')
def delete(id):
    delete_task(id)
    return redirect(url_for('index'))

if __name__=='__main__':
    pay.run(debug=True, port=5001)
